<?php
session_start();

// Vérifie si l'utilisateur est authentifié
if (!isset($_SESSION['authenticated'])) {
    header('Location: login.php');
    exit;
}
?>

<?php
// Chemin vers le répertoire contenant le fichier SQL compressé
$directory = '/var/www/html/csv/apache';

// Vérifier si le répertoire existe et est accessible
if (!is_dir($directory)) {
    die('Erreur: Répertoire non trouvé.');
}

// Trouver le fichier SQL compressé dans le répertoire
$sqlFiles = glob("$directory/*.sql.gz");

if (empty($sqlFiles)) {
    die('Erreur: Aucun fichier SQL compressé trouvé dans le répertoire.');
}

// Utiliser le premier fichier SQL compressé trouvé
$sqlFile = $sqlFiles[0];
$sqlFileName = basename($sqlFile);

// Déclencher le téléchargement du fichier SQL compressé
if (file_exists($sqlFile)) {
    // Définir les en-têtes HTTP pour le téléchargement
    header('Content-Type: application/gzip');
    header('Content-Disposition: attachment; filename="' . $sqlFileName . '"');
    header('Content-Length: ' . filesize($sqlFile));

    // Lire et envoyer le fichier au navigateur
    readfile($sqlFile);

    // Supprimer le fichier SQL compressé après l'avoir envoyé
    unlink($sqlFile);

    exit;
} else {
    die('Erreur: Le fichier SQL compressé n\'existe pas.');
}
?>
